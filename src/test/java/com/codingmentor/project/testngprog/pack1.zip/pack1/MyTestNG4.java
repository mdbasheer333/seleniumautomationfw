package com.codingmentor.project.testngprog.pack1;

import org.testng.annotations.Test;

public class MyTestNG4 {

	
	@Test(invocationCount = 3)
	public void mytest1() {
		System.out.println("MyTestNG1 - this is my test1 ");
	}
	
	
}
